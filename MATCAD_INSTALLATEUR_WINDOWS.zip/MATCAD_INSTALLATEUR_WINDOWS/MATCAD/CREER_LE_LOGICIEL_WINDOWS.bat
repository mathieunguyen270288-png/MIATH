@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo   MATCAD - Creation Windows
 echo ==========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js n'est pas installe.
  echo Installe la version LTS depuis https://nodejs.org puis relance ce fichier.
  pause
  exit /b 1
)
echo Etape 1/2 : telechargement des composants necessaires...
call npm install
if errorlevel 1 (
  echo Echec de npm install. Verifie ta connexion Internet et relance.
  pause
  exit /b 1
)
echo.
echo Etape 2/2 : creation du programme Windows...
call npm run dist:win
if errorlevel 1 (
  echo La creation a echoue. Lis le message d'erreur ci-dessus.
  pause
  exit /b 1
)
echo.
echo Termine ! Les fichiers installables se trouvent dans le dossier dist.
explorer "%~dp0dist"
pause
