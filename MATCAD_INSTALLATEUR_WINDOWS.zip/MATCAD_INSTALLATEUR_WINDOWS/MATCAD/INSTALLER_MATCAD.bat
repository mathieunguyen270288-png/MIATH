@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title MATCAD - Création de l'installateur Windows

echo.
echo  =====================================================
echo       MATCAD - CREATION DE L'INSTALLATEUR WINDOWS
echo  =====================================================
echo.
echo Ce programme va fabriquer :
echo   - MATCAD-Setup.exe (installateur Windows)
echo   - MATCAD-Portable.exe (version sans installation)
echo.
echo Prerequis :
echo   1. Windows 10 ou 11 en 64 bits
echo   2. Node.js LTS installe depuis https://nodejs.org
echo   3. Une connexion Internet pendant la compilation
echo.
pause

where node >nul 2>nul
if errorlevel 1 (
  echo ERREUR : Node.js n'est pas installe ou n'est pas dans PATH.
  echo Installe Node.js LTS puis redemarre cette fenetre.
  start "" "https://nodejs.org"
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERREUR : npm est introuvable. Reinstalle Node.js LTS.
  pause
  exit /b 1
)

echo.
echo [1/3] Verification des versions...
node --version
npm --version

echo.
echo [2/3] Installation des composants de MATCAD...
call npm install
if errorlevel 1 (
  echo.
  echo ECHEC : installation des composants.
  echo Verifie la connexion Internet puis relance ce fichier.
  pause
  exit /b 1
)

echo.
echo [3/3] Construction de l'installateur Windows...
call npm run dist:win
if errorlevel 1 (
  echo.
  echo ECHEC : la compilation a echoue.
  echo Lis le message d'erreur ci-dessus et relance apres correction.
  pause
  exit /b 1
)

echo.
echo =====================================================
echo   TERMINÉ !
echo   Les fichiers sont dans le dossier dist.
echo =====================================================
echo.
if exist "dist" explorer "%~dp0dist"
pause
