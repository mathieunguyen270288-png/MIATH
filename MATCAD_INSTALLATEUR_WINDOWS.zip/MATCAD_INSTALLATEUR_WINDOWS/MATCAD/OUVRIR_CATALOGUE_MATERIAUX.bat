@echo off
chcp 65001 >nul
start "" "%~dp0materials\Catalogue\Catalogue_MATCAD.html"
