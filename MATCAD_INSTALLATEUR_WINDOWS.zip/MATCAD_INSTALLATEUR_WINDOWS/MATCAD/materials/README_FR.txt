Bibliothèque MATCAD intégrée à l'application.
Catalogue principal : Bibliotheque/matcad_materials.json
Textures : Bibliotheque/*/Textures/*.jpg
Catalogue web autonome : Catalogue/Catalogue_MATCAD.html
